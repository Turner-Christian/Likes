function likeCount(id) {
    document.querySelector(id).innerText++
}